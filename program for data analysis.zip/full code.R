# ============================================================
# Name: BASHAR MOHAMMED Hasan
# TP Number: 085153
#
# Objective 1:
#   To analyze how the flow duration (dur) varies across
#   different attack categories.
#
# Objective 2:
#   To investigate whether packet rate (rate) differs
#   between normal and attack traffic.
# ============================================================

library(tidyverse)

# -----------------------------
# Step 1: Import Dataset
# -----------------------------
unsw <- read_csv("5. UNSW_NB15 (2).csv")

glimpse(unsw)
summary(unsw)

# -----------------------------
# Step 2: Select required variables
# -----------------------------
my_data <- unsw %>%
  select(dur, rate, attack_cat, label)

glimpse(my_data)
summary(my_data)

# -----------------------------
# Step 3: Data Type Checking
# -----------------------------
my_data <- my_data %>%
  mutate(
    dur = as.numeric(dur),
    rate = as.numeric(rate),
    attack_cat = as.factor(attack_cat),
    label = as.factor(label)
  )

str(my_data)
summary(my_data)

# -----------------------------
# Step 4: Missing Values Check
# -----------------------------
colSums(is.na(my_data))

# -----------------------------
# Step 5: Outlier Detection
# -----------------------------

par(mfrow = c(1, 2))
boxplot(my_data$dur, main = "Duration (dur)", col = "skyblue")
boxplot(my_data$rate, main = "Packet Rate (rate)", col = "orange")

# IQR method
Q1_dur <- quantile(my_data$dur, 0.25)
Q3_dur <- quantile(my_data$dur, 0.75)
IQR_dur <- Q3_dur - Q1_dur
dur_outliers <- sum(my_data$dur < Q1_dur - 1.5 * IQR_dur |
                      my_data$dur > Q3_dur + 1.5 * IQR_dur)

Q1_rate <- quantile(my_data$rate, 0.25)
Q3_rate <- quantile(my_data$rate, 0.75)
IQR_rate <- Q3_rate - Q1_rate
rate_outliers <- sum(my_data$rate < Q1_rate - 1.5 * IQR_rate |
                       my_data$rate > Q3_rate + 1.5 * IQR_rate)

dur_outliers
rate_outliers

# -----------------------------
# Step 6: Final Validation
# -----------------------------
glimpse(my_data)
summary(my_data)

# ============================================================
# Objective 1 — Summary Statistics
# ============================================================

dur_summary <- my_data %>%
  group_by(attack_cat) %>%
  summarise(
    count = n(),
    mean_dur = mean(dur),
    median_dur = median(dur),
    max_dur = max(dur),
    min_dur = min(dur)
  )

dur_summary

# -----------------------------
# Objective 1 — Chart
# -----------------------------
ggplot(my_data, aes(x = attack_cat, y = dur)) +
  geom_boxplot(fill = "skyblue") +
  labs(
    title = "Flow Duration by Attack Category",
    x = "Attack Category",
    y = "Duration (dur)"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# ============================================================
# Objective 2 — Summary Statistics
# ============================================================

rate_summary <- my_data %>%
  group_by(label) %>%
  summarise(
    count = n(),
    mean_rate = mean(rate),
    median_rate = median(rate),
    max_rate = max(rate),
    min_rate = min(rate)
  )

rate_summary

# -----------------------------
# Objective 2 — Chart
# -----------------------------
ggplot(my_data, aes(x = label, y = rate)) +
  geom_boxplot(fill = "orange") +
  labs(
    title = "Packet Rate by Traffic Label (Normal vs Attack)",
    x = "Traffic Type (0 = Normal, 1 = Attack)",
    y = "Packet Rate (rate)"
  ) +
  theme_minimal()

# ============================================================
# Extra Feature — Flow Duration by Traffic Label
# ============================================================

extra_feature <- my_data %>%
  group_by(label) %>%
  summarise(
    avg_dur = mean(dur),
    median_dur = median(dur),
    max_dur = max(dur)
  )

extra_feature

ggplot(my_data, aes(x = label, y = dur)) +
  geom_boxplot(fill = "lightgreen") +
  labs(
    title = "Flow Duration by Traffic Label (Extra Feature)",
    x = "Traffic Type (0 = Normal, 1 = Attack)",
    y = "Duration (dur)"
  ) +
  theme_minimal()









# ======================================================================
# Name: Mazen Sami Hussein Otaifah
# TP Number: TP084894
#
# Objective 1:
# To analyze how the feature 'ct_src_dport_ltm' varies across attack categories.
#
# Objective 2:
# To analyze how the feature 'ct_state_ttl' varies across attack categories.
#
# Supporting Features (Extra Features):
# spkts → supporting analysis for Objective 1
# dbytes → supporting analysis for Objective 2
# ======================================================================


# ======================================================================
# 1) LOAD THE DATA
# ======================================================================
data <- read.csv("UNSW_NB15.csv")


# ======================================================================
# 2) SELECT RELEVANT FEATURES (MAIN + SUPPORTING)
# ======================================================================
mydata <- data[, c("ct_src_dport_ltm",
                   "ct_state_ttl",
                   "spkts",
                   "dbytes",
                   "attack_cat")]

# Convert attack_cat to factor
mydata$attack_cat <- as.factor(mydata$attack_cat)


# ======================================================================
# 3) REMOVE MISSING VALUES
# ======================================================================
mydata_clean <- na.omit(mydata)


# ======================================================================
# 4) OUTLIER REMOVAL FUNCTION
# ======================================================================
remove_outliers <- function(x) {
  Q1 <- quantile(x, 0.25, na.rm = TRUE)
  Q3 <- quantile(x, 0.75, na.rm = TRUE)
  IQR_value <- Q3 - Q1
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 + 1.5 * IQR_value
  x[x < lower | x > upper] <- NA
  return(x)
}


# ======================================================================
# 5) APPLY OUTLIER REMOVAL TO MAIN OBJECTIVE FEATURES
# ======================================================================
mydata_clean$ct_src_dport_ltm <- remove_outliers(mydata_clean$ct_src_dport_ltm)
mydata_clean$ct_state_ttl     <- remove_outliers(mydata_clean$ct_state_ttl)


# ======================================================================
# 6) FINAL CLEAN DATA (NO NAs & NO OUTLIERS)
# ======================================================================
mydata_clean2 <- na.omit(mydata_clean)


# ======================================================================
# 7) LOAD DPLYR LIBRARY
# ======================================================================
library(dplyr)


# ======================================================================
# 8) OBJECTIVE 1 – BAR CHART (ct_src_dport_ltm)
# ======================================================================
mean_obj1 <- mydata_clean2 %>%
  group_by(attack_cat) %>%
  summarise(mean_value = mean(ct_src_dport_ltm))

barplot(mean_obj1$mean_value,
        names.arg = mean_obj1$attack_cat,
        las = 2,
        col = "skyblue",
        main = "Average ct_src_dport_ltm by Attack Category",
        xlab = "Attack Category",
        ylab = "Average ct_src_dport_ltm",
        cex.names = 0.7)


# ======================================================================
# 9) OBJECTIVE 2 – BAR CHART (ct_state_ttl)
# ======================================================================
mean_obj2 <- mydata_clean2 %>%
  group_by(attack_cat) %>%
  summarise(mean_value = mean(ct_state_ttl))

barplot(mean_obj2$mean_value,
        names.arg = mean_obj2$attack_cat,
        las = 2,
        col = "lightgreen",
        main = "Average ct_state_ttl by Attack Category",
        xlab = "Attack Category",
        ylab = "Average ct_state_ttl",
        cex.names = 0.7)


# ======================================================================
# 10) SUPPORTING FEATURE FOR OBJECTIVE 1 (spkts)
# ======================================================================
support1 <- mydata_clean2 %>%
  group_by(attack_cat) %>%
  summarise(mean_spkts = mean(spkts, na.rm = TRUE))

barplot(support1$mean_spkts,
        names.arg = support1$attack_cat,
        las = 2,
        col = "orange",
        main = "Average spkts by Attack Category",
        xlab = "Attack Category",
        ylab = "Average spkts",
        cex.names = 0.7)


# ======================================================================
# 11) SUPPORTING FEATURE FOR OBJECTIVE 2 (dbytes)
# ======================================================================
support2 <- mydata_clean2 %>%
  group_by(attack_cat) %>%
  summarise(mean_dbytes = mean(dbytes, na.rm = TRUE))

barplot(support2$mean_dbytes,
        names.arg = support2$attack_cat,
        las = 2,
        col = "purple",
        main = "Average dbytes by Attack Category",
        xlab = "Attack Category",
        ylab = "Average dbytes",
        cex.names = 0.7)











# ======================================================================
# Name: Nour Mohamed Mahmoud Mohamed Mohamed Ismail
# TP Number: TP081664
#
# Objective 1:
# To analyze how source and destination inter-packet times (sinpkt, dinpkt)
# vary across attack categories and normal traffic.
#
# Objective 2:
# To examine how source and destination jitter (sjit, djit) differ across
# attack categories and how strongly they correlate during attacks.
#
# Extra Feature:
# Feature importance analysis using Random Forest (sinpkt, dinpkt, sjit, djit)
# ======================================================================


# ======================================================================
# 1) Load Libraries
# ======================================================================
library(tidyverse)
library(dplyr)


# ======================================================================
# 2) Import Dataset
# ======================================================================
data <- read.csv("5. UNSW_NB15.csv", stringsAsFactors = FALSE)

str(data)
head(data)


# ======================================================================
# 3) Remove Duplicates
# ======================================================================
sum(duplicated(data))     # count duplicates
data <- distinct(data)


# ======================================================================
# 4) Handle Missing Values
# ======================================================================

# Count missing values
colSums(is.na(data))

# Replace missing numeric values with median
data <- data %>%
  mutate(across(where(is.numeric),
                ~ ifelse(is.na(.), median(., na.rm = TRUE), .)))

# Mode function for categorical values
get_mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}

# Replace missing categorical values with mode
data <- data %>%
  mutate(across(where(is.character),
                ~ ifelse(. == "" | is.na(.), get_mode(.), .)))


# ======================================================================
# 5) Convert to Factor
# ======================================================================
data$attack_cat <- as.factor(data$attack_cat)
data$label <- as.factor(data$label)


# ======================================================================
# 6) Feature Selection
# ======================================================================
df <- data %>%
  select(attack_cat, label, sinpkt, dinpkt, sjit, djit)


# ======================================================================
# 7) Remove Impossible Negative Values
# ======================================================================
df$sinpkt[df$sinpkt < 0] <- NA
df$dinpkt[df$dinpkt < 0] <- NA
df$sjit[df$sjit < 0] <- NA
df$djit[df$djit < 0] <- NA

# Refill missing numeric values
df <- df %>%
  mutate(across(where(is.numeric),
                ~ ifelse(is.na(.), median(., na.rm = TRUE), .)))


# ======================================================================
# 8) Summary of Key Variables
# ======================================================================
summary(df[, c("sinpkt", "dinpkt", "sjit", "djit")])


# ======================================================================
# 9) Outlier Checks (Boxplots)
# ======================================================================
boxplot(df$sinpkt, main = "Outlier Check: sinpkt")
boxplot(df$dinpkt, main = "Outlier Check: dinpkt")
boxplot(df$sjit,  main = "Outlier Check: sjit")
boxplot(df$djit,  main = "Outlier Check: djit")


# ======================================================================
# 10) Validate Categories
# ======================================================================
table(df$attack_cat)
table(df$label)

colSums(is.na(df))    # final missing value check


# ======================================================================
# 11) Objective 1 – Inter-Packet Time Analysis
# ======================================================================
summary_pkt <- df %>%
  group_by(attack_cat) %>%
  summarise(
    mean_sinpkt   = mean(sinpkt, na.rm = TRUE),
    median_sinpkt = median(sinpkt, na.rm = TRUE),
    mean_dinpkt   = mean(dinpkt, na.rm = TRUE),
    median_dinpkt = median(dinpkt, na.rm = TRUE),
    count = n()
  )

summary_pkt


# Boxplots for sinpkt
ggplot(df, aes(x = attack_cat, y = sinpkt, fill = attack_cat)) +
  geom_boxplot() +
  theme_minimal() +
  labs(
    title = "Source Inter-Packet Time (sinpkt) Across Attack Categories",
    x = "Attack Category",
    y = "sinpkt"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# Boxplots for dinpkt
ggplot(df, aes(x = attack_cat, y = dinpkt, fill = attack_cat)) +
  geom_boxplot() +
  theme_minimal() +
  labs(
    title = "Destination Inter-Packet Time (dinpkt) Across Attack Categories",
    x = "Attack Category",
    y = "dinpkt"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# ======================================================================
# 12) Objective 2 – Jitter Analysis
# ======================================================================
jitter_summary <- df %>%
  group_by(attack_cat) %>%
  summarise(
    mean_sjit   = mean(sjit, na.rm = TRUE),
    median_sjit = median(sjit, na.rm = TRUE),
    mean_djit   = mean(djit, na.rm = TRUE),
    median_djit = median(djit, na.rm = TRUE),
    count = n()
  )

jitter_summary


# Correlation ONLY during attacks (label = 1)
attack_only <- df %>% filter(label == 1)
cor_sjit_djit <- cor(attack_only$sjit, attack_only$djit, use = "complete.obs")
cor_sjit_djit


# Line Plot Comparing Jitter
jitter_long <- df %>%
  group_by(attack_cat) %>%
  summarise(
    mean_sjit = mean(sjit, na.rm = TRUE),
    mean_djit = mean(djit, na.rm = TRUE)
  ) %>%
  pivot_longer(cols = c(mean_sjit, mean_djit),
               names_to = "type",
               values_to = "value")

ggplot(jitter_long, aes(x = attack_cat, y = value, group = type, color = type)) +
  geom_line(size = 1.2) +
  geom_point(size = 3) +
  theme_minimal() +
  labs(
    title = "Comparison of Source & Destination Jitter Across Attack Categories",
    x = "Attack Category",
    y = "Mean Jitter Value",
    color = "Jitter Type"
  ) +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# ======================================================================
# 13) Extra Feature – Random Forest Feature Importance
# ======================================================================
library(randomForest)

set.seed(123)

# Use 10% sample for speed
df_small <- df %>% sample_frac(0.10)

rf_model <- randomForest(
  attack_cat ~ sinpkt + dinpkt + sjit + djit,
  data = df_small,
  importance = TRUE,
  ntree = 100
)

importance(rf_model)

varImpPlot(rf_model,
           main = "Feature Importance (Random Forest)")






# ============================================================
# Name: FAHAD BIN ZAHARUDDIN FIKRI
# TP Number: TP085541
#
# Features Used:
#   Main Features:
#       - sloss
#       - dloss
#
#   Supporting Analyses:
#       - scaled versions of sloss & dloss
#       - statistical tests (Wilcoxon, Chi-Square, GLM)
#
#   Labels:
#       - label (Normal vs Attack)
# ============================================================


# ============================================================
# 1) Load required packages (install if missing)
# ============================================================
needed <- c("readr", "dplyr", "ggplot2", "janitor", "tibble")

to_install <- needed[!(needed %in% installed.packages()[,"Package"])]
if (length(to_install)) install.packages(to_install, dependencies = TRUE)

library(readr)
library(dplyr)
library(ggplot2)
library(janitor)
library(tibble)


# ============================================================
# 2) Set working directory
# ============================================================
setwd("D:/Fahad/University/APU/Year 2 Sem 1/Programming For Data Analysis/Assignment/Work")


# ============================================================
# 3) Load dataset & clean column names
# ============================================================
df <- read_csv("UNSW_NB15.csv", show_col_types = FALSE)
df <- clean_names(df)   # Normalize column names


# ============================================================
# 4) Fix columns incorrectly imported as lists/matrices
# ============================================================
bad_cols <- names(df)[sapply(df, function(x) is.list(x) || inherits(x, "matrix"))]

if (length(bad_cols) > 0) {
  df[bad_cols] <- lapply(df[bad_cols], function(col)
    vapply(col, function(cell){
      if (is.null(cell)) return(NA_character_)
      if (is.atomic(cell)) return(as.character(cell))
      paste(unlist(cell), collapse = ";")
    }, FUN.VALUE = character(1))
  )
}


# ============================================================
# 5) Verify required columns exist
# ============================================================
required_keys <- c("sloss", "dloss", "label")
if (!all(required_keys %in% names(df)))
  stop(paste("Missing required columns:", paste(setdiff(required_keys, names(df)), collapse=", ")))


# ============================================================
# 6) Select required columns first
# ============================================================
df <- df %>% select(all_of(required_keys), everything())


# ============================================================
# 7) Convert variable types (numeric + factor)
# ============================================================
df <- df %>% mutate(
  label = as.factor(label),
  sloss = as.numeric(sloss),
  dloss = as.numeric(dloss)
)


# ============================================================
# 8) Mode function (used for categorical missing values)
# ============================================================
Mode <- function(x){
  ux <- unique(x[!is.na(x)])
  ux[which.max(tabulate(match(x, ux)))]
}


# ============================================================
# 9) Replace missing values
#    - numeric → median
#    - categorical → mode
# ============================================================
for (v in c("sloss", "dloss"))
  if (any(is.na(df[[v]]))) df[[v]][is.na(df[[v]])] <- median(df[[v]], na.rm = TRUE)

if (any(is.na(df$label)))
  df$label[is.na(df$label)] <- Mode(df$label)


# ============================================================
# 10) Create scaled versions of sloss & dloss
# ============================================================
df <- df %>% mutate(
  sloss_scaled = as.numeric(scale(sloss)),
  dloss_scaled = as.numeric(scale(dloss))
)


# ============================================================
# 11) Save cleaned file
# ============================================================
if (!dir.exists("outputs")) dir.create("outputs")
write_csv(df, file.path("outputs", "UNSW_NB15_cleaned_sloss_dloss.csv"))


# ============================================================
# 12) Sample data for plotting (for performance)
# ============================================================
plot_data <- if (nrow(df) > 20000) sample_n(df, 20000) else df


# ============================================================
# 13) Boxplots (sloss & dloss)
# ============================================================
p1 <- ggplot(df, aes(x = label, y = sloss, fill = label)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "sloss by label", x = "label", y = "sloss")

ggsave("outputs/box_sloss_by_label.png", p1, width=8, height=5, dpi=150)


p2 <- ggplot(df, aes(x = label, y = dloss, fill = label)) +
  geom_boxplot() +
  theme_minimal() +
  labs(title = "dloss by label", x = "label", y = "dloss")

ggsave("outputs/box_dloss_by_label.png", p2, width=8, height=5, dpi=150)


# ============================================================
# 14) Scatter plot (sloss vs dloss)
# ============================================================
p3 <- ggplot(plot_data, aes(x = sloss, y = dloss, color = label)) +
  geom_point(alpha = 0.3) +
  theme_minimal() +
  labs(title = "sloss vs dloss by label", x = "sloss", y = "dloss")

ggsave("outputs/scatter_sloss_dloss_label.png", p3, width=8, height=5, dpi=150)


# ============================================================
# 15) Basic data checks
# ============================================================
cat("rows:", nrow(df), "cols:", ncol(df), "\n")
print(head(df, 6))
print(str(df))


# ============================================================
# 16) Missing counts
# ============================================================
print(sapply(df[c("sloss","dloss","label")], function(x) sum(is.na(x))))


# ============================================================
# 17) Summary statistics by label
# ============================================================
print(by(df$sloss, df$label, summary))
print(by(df$dloss, df$label, summary))


# ============================================================
# 18) Outlier counts using IQR
# ============================================================
outlier_counts <- list()

for (v in c("sloss","dloss")) {
  x <- df[[v]]
  Q1 <- quantile(x, .25, na.rm=TRUE)
  Q3 <- quantile(x, .75, na.rm=TRUE)
  IQRv <- Q3 - Q1
  lower <- Q1 - 1.5*IQRv
  upper <- Q3 + 1.5*IQRv
  outlier_counts[[v]] <- sum(x < lower | x > upper, na.rm=TRUE)
}
print(outlier_counts)


# ============================================================
# 19) Count negative & zero values
# ============================================================
print(sapply(df[c("sloss","dloss")], function(x)
  c(neg = sum(x < 0, na.rm=TRUE), zero = sum(x == 0, na.rm=TRUE))))


# ============================================================
# 20) Check scaled variable statistics
# ============================================================
print(sapply(df[c("sloss_scaled","dloss_scaled")], function(x)
  c(mean = mean(x, na.rm=TRUE), sd = sd(x, na.rm=TRUE))))


# ============================================================
# 21) Wilcoxon statistical tests
# ============================================================
wil_sloss <- wilcox.test(sloss ~ label, data = df)
wil_dloss <- wilcox.test(dloss ~ label, data = df)


# ============================================================
# 22) Compute Cohen's d effect size
# ============================================================
cohen_d <- function(x, g){
  levs <- levels(g)
  x1 <- x[g==levs[1]]
  x2 <- x[g==levs[2]]
  n1 <- length(x1); n2 <- length(x2)
  m1 <- mean(x1, na.rm=TRUE); m2 <- mean(x2, na.rm=TRUE)
  s1 <- var(x1, na.rm=TRUE); s2 <- var(x2, na.rm=TRUE)
  pooled_sd <- sqrt(((n1-1)*s1 + (n2-1)*s2)/(n1+n2-2))
  (m1 - m2) / pooled_sd
}

d_sloss <- cohen_d(df$sloss, df$label)
d_dloss <- cohen_d(df$dloss, df$label)


# ============================================================
# 23) Chi-square + Cramer's V
# ============================================================
df$sloss_q <- cut(df$sloss, breaks = 4, include.lowest = TRUE)
df$dloss_q <- cut(df$dloss, breaks = 4, include.lowest = TRUE)

tab_sloss <- table(df$sloss_q, df$label)
tab_dloss <- table(df$dloss_q, df$label)

chi_sloss_sim <- chisq.test(tab_sloss, simulate.p.value = TRUE)
chi_dloss_sim <- chisq.test(tab_dloss, simulate.p.value = TRUE)

cramers_v <- function(x){
  chi <- suppressWarnings(chisq.test(x))
  n <- sum(x)
  phi2 <- as.numeric(chi$statistic)/n
  r <- nrow(x); k <- ncol(x)
  sqrt(phi2 / min(r-1, k-1))
}

cv_sloss <- cramers_v(tab_sloss)
cv_dloss <- cramers_v(tab_dloss)


# ============================================================
# 24) Logistic regression model
# ============================================================
df$label_num <- ifelse(as.character(df$label) == levels(df$label)[1], 0, 1)
glm_model <- glm(label_num ~ sloss + dloss, data=df, family=binomial())
glm_warnings <- warnings()


# ============================================================
# 25) Summary table of statistical results
# ============================================================
results <- tibble(
  test = c("wil_sloss_p","wil_dloss_p","cohen_d_sloss","cohen_d_dloss",
           "chi_sloss_p","chi_dloss_p","cramers_v_sloss","cramers_v_dloss","glm_aic"),
  value = c(
    wil_sloss$p.value, wil_dloss$p.value,
    d_sloss, d_dloss,
    chi_sloss_sim$p.value, chi_dloss_sim$p.value,
    cv_sloss, cv_dloss,
    AIC(glm_model)
  )
)

write_csv(results, file.path("outputs","stat_results_summary_sloss_dloss.csv"))


# ============================================================
# 26) Print results
# ============================================================
print(wil_sloss)
print(wil_dloss)

print(chi_sloss_sim)
print(chi_dloss_sim)

print(cv_sloss)
print(cv_dloss)

print(glm_warnings)
print(summary(glm_model))


# ============================================================
# 27) Display output files
# ============================================================
print(list.files("outputs"))









# ======================================================================
# Student Name: Bektay Abdinur
# TP Number: TP076035
#
# Objective 1:
# To analyze how source packet counts (spkts) vary across attack categories.
#
# Objective 2:
# To analyze how source byte transfers (sbytes) differ across attack categories.
# ======================================================================


# ======================================================================
# 1) Load Dataset
# ======================================================================
dataset_raw <- read.csv("dataset.csv", header = TRUE, stringsAsFactors = FALSE)


# ======================================================================
# 2) Remove Duplicate Rows
# ======================================================================
dataset_clean <- dataset_raw[!duplicated(dataset_raw), ]


# ======================================================================
# 3) Handle Missing Values
# ======================================================================

# Count missing values per column
colSums(is.na(dataset_clean))

# Replace missing numeric values with the column median
numeric_cols <- sapply(dataset_clean, is.numeric)

for (col in names(dataset_clean)[numeric_cols]) {
  med <- median(dataset_clean[[col]], na.rm = TRUE)
  dataset_clean[[col]][is.na(dataset_clean[[col]])] <- med
}


# ======================================================================
# 4) Convert Attack Category to Factor (Categorical)
# ======================================================================
dataset_clean$attack_cat <- as.factor(dataset_clean$attack_cat)


# ======================================================================
# 5) Check for Negative or Zero Values (Only the relevant variables)
# ======================================================================
summary(dataset_clean[, c("spkts", "sbytes")])


# ======================================================================
# 6) Outlier Inspection Using Boxplots
# ======================================================================
boxplot(dataset_clean$spkts, main = "Outlier Check – spkts")
boxplot(dataset_clean$sbytes, main = "Outlier Check – sbytes")


# ======================================================================
# 7) Summary Statistics for Both Objectives
# ======================================================================

# Objective 1: spkts across attack categories
summary_spkts <- aggregate(spkts ~ attack_cat, data = dataset_clean, summary)
print(summary_spkts)

# Objective 2: sbytes across attack categories
summary_sbytes <- aggregate(sbytes ~ attack_cat, data = dataset_clean, summary)
print(summary_sbytes)


# ======================================================================
# 8) Visualization (Boxplots for Both Objectives)
# ======================================================================
library(ggplot2)

# Boxplot for spkts
ggplot(dataset_clean, aes(x = attack_cat, y = spkts)) +
  geom_boxplot(outlier.alpha = 0.3) +
  scale_y_log10() +
  labs(
    title = "Source Packets (spkts) Across Attack Categories",
    x = "Attack Category",
    y = "spkts (log10 scale)"
  ) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Boxplot for sbytes
ggplot(dataset_clean, aes(x = attack_cat, y = sbytes)) +
  geom_boxplot(outlier.alpha = 0.3) +
  scale_y_log10() +
  labs(
    title = "Source Bytes (sbytes) Across Attack Categories",
    x = "Attack Category",
    y = "sbytes (log10 scale)"
  ) +
  theme_bw() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# ======================================================================
# 9) Hypothesis Testing (Kruskal-Wallis Test)
# ======================================================================

# Objective 1: spkts
# H0: Median spkts is equal across attack categories
# HA: At least one attack category differs
kruskal_spkts <- kruskal.test(spkts ~ attack_cat, data = dataset_clean)
print(kruskal_spkts)

# Objective 2: sbytes
# H0: Median sbytes is equal across attack categories
# HA: At least one attack category differs
kruskal_sbytes <- kruskal.test(sbytes ~ attack_cat, data = dataset_clean)
print(kruskal_sbytes)


# ======================================================================
# 10) Save Cleaned Dataset (Optional)
# ======================================================================
write.csv(dataset_clean, "dataset_cleaned.csv", row.names = FALSE)

# ======================================================================
# END OF CODE
# ======================================================================
